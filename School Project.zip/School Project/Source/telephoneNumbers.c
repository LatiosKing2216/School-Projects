// Program that converts a 7-digit phone number into every one of it's 2187 word variants
// These words are written to phoneNumbers.txt character by character
// Created by Sabastian Stevens on 4/14/2017
#include <stdio.h>
#include <string.h>
#define SIZE 7

int main(void)
{
	// Create an char array to represent the phone number
	char phoneNum[] = { "5248936" };

	// Pointer that will point to phoneNumbers.txt
	FILE *filePtr;

	int recordsWritten = 0; // Tracks the number of words written to the file
	int counters[SIZE] = { 0 }; // Used to test which character should be written
	int convertedNumber[SIZE] = { 0 }; // Used to populate the counters[] array with the correct values
	int baseDigits[3] = { 0, 1, 2 }; // Used to help determine the appropriate character between the 3 options
	int numToConvert = 0; // Increments after each word is printed (to ensure the words are unique)
	int numToConvertCopy = 0; // Copy of numToConvert that is used in calculations

	puts("This program will convert a 7-digit phone number (524-8936) into its 2187 possible word variants.");
	puts("It will then write these word variants to a sequential access file named phoneNumbers.txt");

	// If file cannot be opened or created, display error and end program
	if ((filePtr = fopen("phoneNumbers.txt", "w")) == NULL)
	{
		puts("Error opening file");
	}
	else
	{
		while (recordsWritten < 2187)
		{
			// Read each number in the phone number and determine which letter it should correspond to
			for (int i = 0; i < SIZE; i++)
			{
				if (phoneNum[i] == '2')
				{
					if (counters[i] == 0) fputc('A', filePtr);
					if (counters[i] == 1) fputc('B', filePtr);
					if (counters[i] == 2) fputc('C', filePtr);
				}
				else if (phoneNum[i] == '3')
				{
					if (counters[i] == 0) fputc('D', filePtr);
					if (counters[i] == 1) fputc('E', filePtr);
					if (counters[i] == 2) fputc('F', filePtr);
				}
				else if (phoneNum[i] == '4')
				{
					if (counters[i] == 0) fputc('G', filePtr);
					if (counters[i] == 1) fputc('H', filePtr);
					if (counters[i] == 2) fputc('I', filePtr);
				}
				else if (phoneNum[i] == '5')
				{
					if (counters[i] == 0) fputc('J', filePtr);
					if (counters[i] == 1) fputc('K', filePtr);
					if (counters[i] == 2) fputc('L', filePtr);
				}
				else if (phoneNum[i] == '6')
				{
					if (counters[i] == 0) fputc('M', filePtr);
					if (counters[i] == 1) fputc('N', filePtr);
					if (counters[i] == 2) fputc('O', filePtr);
				}
				else if (phoneNum[i] == '7')
				{
					if (counters[i] == 0) fputc('P', filePtr);
					if (counters[i] == 1) fputc('R', filePtr);
					if (counters[i] == 2) fputc('S', filePtr);
				}
				else if (phoneNum[i] == '8')
				{
					if (counters[i] == 0) fputc('T', filePtr);
					if (counters[i] == 1) fputc('U', filePtr);
					if (counters[i] == 2) fputc('V', filePtr);
				}
				else if (phoneNum[i] == '9')
				{
					if (counters[i] == 0) fputc('W', filePtr);
					if (counters[i] == 1) fputc('X', filePtr);
					if (counters[i] == 2) fputc('Y', filePtr);
				}
			}

			// Increment numToConvert and copy it for calculations
			numToConvert++;
			numToConvertCopy = numToConvert;

			// Convert the copy into a base 3 integer array
			for (int i = 0; i < SIZE; i++)
			{
				convertedNumber[i] = numToConvertCopy % 3;
				numToConvertCopy = numToConvertCopy / 3;
			}
			
			// Copy the values in convertedNumber[] into counters[], so that a unique character
			// set can be printed in the next pass
			for (int i = 0; i < SIZE; i++) counters[i] = baseDigits[convertedNumber[i]];

			// Increment recordsWritten and write a newline for readability
			recordsWritten++;
			fputc('\n', filePtr);
		}
	}

	// Close the file
	fclose(filePtr);

	puts("The word variants have been written to phoneNumbers.txt, located in the Application folder.");
	getchar();
	getchar();
}


