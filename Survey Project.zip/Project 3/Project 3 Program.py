# Project 3 Program
# A program that is part of a project that analyzes horror movie preferences
# and the intensity of 9 common phobias that a sample size of 1,010 have.
# The hypothesis is that if a people have a major phobia of something, they
# will generally not like watching horror movies.
# Created by Sabastian Stevens on 11/21/2017

import sqlite3

# This function serves as an easily reusable way to create and display
# multiple tables of information associated with testing the hypothesis
# explained above
def createTable(string):
    # Connect to the database and create a handler for its contents
    conn = sqlite3.connect('YoungPeopleSurvey.db')
    cur = conn.cursor()

    # Select the column from the Phobias table whose name matches the passed
    # in phobia string, as well as counts of people with different
    # intensities of the phobia. (with 1 being the lowest, 5 being the highest,
    # and -1 being N/A) Then, for each of the levels of the phobia that is
    # reported, an average rating of the group's enjoyment of horror movies
    # is calculated using the MovieGenres table.
    cur.execute('Select distinct ' + string + ' as Rating, count(' + string + ') as NumRatingsOf' + string + 'Phobia, avg(Horror) as HorrorMovieRatingAvg from Phobias join MovieGenres on Phobias.PersonID = MovieGenres.PersonID group by ' + string)

    # Print out the names of the columns over their associated records
    for col in cur.description:
        print(col[0], end='  ')

    print()

    # Print each row of records associated with the selected columns
    for row in cur:
        print(str(row[0]) + '                      ' + str(row[1]) + '                      ' + str(row[2]))

    print('')

    # Close the database file and its handler
    cur.close()
    conn.close()

# Introduce the user to the program and explain its goal
print('This program will test the hypothesis that people with high intensities')
print('of different phobias will generally not enjoy horror movies. It will do')
print('so by calculating an average rating of the enjoyment that people with')
print('different levels of phobia have for horror movies, using data from a')
print('sample size of 1,010 people.')
print('(Note: the rating system is 1-5, and a value of -1 represents a N/A rating)')
print('')

# Create a table of records to display for each phobia using multiple calls
# to the function defined above
createTable('Flying')
createTable('Storm')
createTable('Darkness')
createTable('Heights')
createTable('Spiders')
createTable('Snakes')
createTable('Ageing')
createTable('DangerousDogs')
createTable('FearOfPublicSpeaking')
